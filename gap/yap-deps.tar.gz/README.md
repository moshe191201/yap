# yap missing-dependency bundle

The `OnlpLab/yap` repo ships a `vendor/` directory that is **incomplete**. It contains
only `github.com/gonuts/commander` and `github.com/gonuts/flag`, but the code also
imports two packages that are not vendored:

| Package | Version here | Imported by |
|---|---|---|
| `github.com/gorilla/mux` | v1.8.0 | `webapi/webapi.go` (`mux.NewRouter`, `mux.Router`) |
| `gopkg.in/yaml.v2` | v2.4.0 | `alg/transition/featurereader.go` (`yaml.Unmarshal`) |

Fetching those two is the *only* thing `go get .` in the README ever did — which is why
the documented build cannot work without network access. This bundle supplies them so
you can skip `go get` entirely.

Both are pure-stdlib leaves: they pull in no further dependencies, so these two are the
complete transitive closure. (`yaml.v2` lists `gopkg.in/check.v1`, but only for its own
tests, which are excluded here.)

`mux` is pinned to **v1.8.0, not v1.8.1**, deliberately: v1.8.1 declares `go 1.20` in its
`go.mod`, which is newer than the Go 1.19.2 toolchain on the target. v1.8.0 declares
`go 1.12`. The API yap uses is identical in both.

## Verification status

Built and run against **go1.19.2 darwin/arm64**, fully offline (`GOPROXY=off`,
`GO111MODULE=off`, clean `GOPATH`, no network fetch of any kind):

- GOPATH mode — `go build .` exits 0, no diagnostics; `./yap` prints its command list.
- Module-mode fallback — `go build -mod=vendor .` exits 0; binary runs.
- `go list -deps` confirms all four dependencies resolve from `<yap>/vendor/`.

Not verified: the runtime model files under `data/` were excluded from the build test,
so this proves the binary **compiles and starts**, not that parsing works end to end.

## Contents

```
vendor/github.com/gorilla/mux/     source only, no _test.go
vendor/gopkg.in/yaml.v2/           source only, no _test.go
fallback-module-mode/go.mod        only needed if GO111MODULE=off is unavailable
fallback-module-mode/modules.txt   ditto
install.sh                         copies vendor/ into your checkout and sanity-checks it
```

## Install

```sh
./install.sh /path/to/yap
```

Uses `cp -Rn`, so it never overwrites the two packages the repo already vendors.

## Then build (GOPATH mode, offline)

```sh
export GOPATH=$HOME/go
export GO111MODULE=off
mkdir -p "$GOPATH/src"
cp -R /path/to/yap "$GOPATH/src/yap"     # must be exactly $GOPATH/src/yap
cd "$GOPATH/src/yap"
go build .
```

The path matters: yap's internal imports are `yap/app`, `yap/webapi`, etc. — bare,
non-domain-qualified paths that only resolve when the tree sits at `$GOPATH/src/yap`.
Do **not** run `go get .`.

Go 1.19.2 supports `GO111MODULE=off` fully, so this is the path to use.

## Module-mode fallback

Not needed on Go 1.19.2, but included and tested in case the toolchain changes:

```sh
cp fallback-module-mode/go.mod      "$GOPATH/src/yap/go.mod"
cp fallback-module-mode/modules.txt "$GOPATH/src/yap/vendor/modules.txt"
cd "$GOPATH/src/yap" && go build -mod=vendor .
```

`module yap` in go.mod is what makes the bare `yap/...` imports resolve locally.

Caveat: the `gonuts/*` entries in `go.mod`/`modules.txt` carry **synthetic** version
numbers (`v0.1.0`) — those packages were vendored before Go modules existed and have no
real tagged version. Harmless, because vendor mode does not checksum-verify vendored
code; it only requires `go.mod` and `modules.txt` to agree with each other, which they
do (verified by the successful build above). The `mux` and `yaml.v2` versions are real.
