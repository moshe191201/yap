module yap

go 1.16

require (
	github.com/gonuts/commander v0.1.0
	github.com/gonuts/flag v0.1.0
	github.com/gorilla/mux v1.8.0
	gopkg.in/yaml.v2 v2.4.0
)
