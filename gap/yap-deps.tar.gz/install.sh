#!/bin/sh
# Install the missing yap dependencies into an existing yap checkout.
# Usage: ./install.sh /path/to/yap
set -eu

YAP="${1:?usage: $0 /path/to/yap-checkout}"

[ -f "$YAP/main.go" ] || { echo "error: $YAP does not look like a yap checkout (no main.go)" >&2; exit 1; }
[ -d "$YAP/vendor" ] || { echo "error: $YAP/vendor missing — wrong or incomplete checkout" >&2; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"

echo "==> copying vendored sources into $YAP/vendor"
# -n: never overwrite anything already present (keeps the repo's own gonuts/* intact)
cp -Rn "$HERE/vendor/." "$YAP/vendor/"

echo "==> verifying package layout"
for p in \
  vendor/github.com/gorilla/mux/mux.go \
  vendor/gopkg.in/yaml.v2/yaml.go \
  vendor/github.com/gonuts/commander/commands.go \
  vendor/github.com/gonuts/flag/flag.go
do
  [ -f "$YAP/$p" ] || { echo "  MISSING: $p" >&2; exit 1; }
  echo "  ok: $p"
done

cat <<EOF

Done. Now build in GOPATH mode (no network, no 'go get'):

  export GOPATH=\$HOME/go
  export GO111MODULE=off
  mkdir -p "\$GOPATH/src"
  # the checkout MUST live at \$GOPATH/src/yap — the imports are 'yap/...'
  [ -e "\$GOPATH/src/yap" ] || cp -R "$YAP" "\$GOPATH/src/yap"
  cd "\$GOPATH/src/yap"
  go build .
  ./yap

If your Go refuses GO111MODULE=off, use the module-mode fallback in this
bundle instead:

  cp $HERE/fallback-module-mode/go.mod           "\$GOPATH/src/yap/go.mod"
  cp $HERE/fallback-module-mode/modules.txt      "\$GOPATH/src/yap/vendor/modules.txt"
  cd "\$GOPATH/src/yap" && go build -mod=vendor .
EOF
